import React from "react";

function Footer(){
    return     <div className="absolute top-0 left-0 w-full z-20 bg-white p-4 shadow-md">

        Hi
    </div>

}

export default Footer;